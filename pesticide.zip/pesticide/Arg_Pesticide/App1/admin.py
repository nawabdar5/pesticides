from django.contrib import admin
from App1.models import *

# Register your models here.
admin.site.register(Contact)
admin.site.register(Product)
admin.site.register(OrderUpdate)
admin.site.register(Orders)